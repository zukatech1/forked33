-- This Script is Part of the ZukaTech Obfuscator
--
-- CffIntegrity.lua
--
-- Injects a CFF magic-constant integrity table.
-- If any constant is tampered with at runtime the script falls into a
-- permanent loop (matches the Luraph CFF_Table anti-tamper pattern).

local Step          = require("ZukaTech.step")
local Ast           = require("ZukaTech.ast")
local Scope         = require("ZukaTech.scope")
local Parser        = require("ZukaTech.parser")
local Enums         = require("ZukaTech.enums")
local RandomStrings = require("ZukaTech.randomStrings")

local CffIntegrity       = Step:extend()
CffIntegrity.Description = "Injects a CFF magic-constant integrity table: if any constant is tampered with at runtime the script falls into a permanent loop (matches the Luraph CFF_Table anti-tamper pattern)."
CffIntegrity.Name        = "CFF Integrity"

CffIntegrity.SettingsDescriptor = {
    TableSize = {
        name        = "TableSize",
        description = "Number of constants in the integrity table (4-16)",
        type        = "number",
        default     = 9,
        min         = 4,
        max         = 16,
    },
    TrapIndex = {
        name        = "TrapIndex",
        description = "Which table index (1-based) is the trap constant. 0 = pick randomly.",
        type        = "number",
        default     = 0,
        min         = 0,
        max         = 16,
    },
}

function CffIntegrity:init(settings) end

-- ── helpers ──────────────────────────────────────────────────────────────────

local function bxor(a, b)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

local function hashMix(v, salt)
    local p   = 2654435761
    local MOD = 2147483647
    local h   = (v * p + salt) % MOD
    h = bxor(h, math.floor(h / 65536))
    return h % MOD
end

local function buildTable(tableSize, trapIdxSetting)
    local constants = {}
    for i = 1, tableSize do
        constants[i] = math.random(1, 2147483646)
    end

    local trapIdx = trapIdxSetting
    if trapIdx < 1 or trapIdx > tableSize then
        trapIdx = math.random(1, tableSize)
    end

    local acc  = constants[1]
    local salt = math.random(1, 65535)
    for i = 2, tableSize do
        acc = hashMix(acc, constants[i] + salt)
    end
    local expected = acc % 2147483647

    return constants, trapIdx, expected, salt
end

-- ── code generation ──────────────────────────────────────────────────────────

-- FIX: Rewrote buildValidationCode using plain string concatenation instead of
-- string.format with %s placeholders. The original had a mismatched arg list
-- where varP was used as both the salt literal AND a function name, and the
-- hashMix function body was referencing undeclared variable names from the
-- wrong format slot. Now each variable is concatenated directly — no slot math.

local function buildValidationCode(constants, trapIdx, expected, salt, tableSize)
    local parts = {}
    for i, v in ipairs(constants) do
        parts[i] = tostring(v)
    end
    local tableLiteral = "{ " .. table.concat(parts, ", ") .. " }"

    local varTbl  = "_cff_" .. RandomStrings.randomString(6)
    local varSalt = "_cs_"  .. RandomStrings.randomString(4)
    local varMOD  = "_cm_"  .. RandomStrings.randomString(4)
    local varBxor = "_bx_"  .. RandomStrings.randomString(4)
    local varMix  = "_hm_"  .. RandomStrings.randomString(4)
    local varOk   = "_ck_"  .. RandomStrings.randomString(4)
    local varAcc  = "_ca_"  .. RandomStrings.randomString(4)
    local varI    = "_ci_"  .. RandomStrings.randomString(3)

    local trapExpected = hashMix(constants[trapIdx], salt + trapIdx) % 2147483647

    local code = "do\n"

    -- table + constants
    code = code .. "    local " .. varTbl  .. " = " .. tableLiteral .. "\n"
    code = code .. "    local " .. varSalt .. " = " .. tostring(salt) .. "\n"
    code = code .. "    local " .. varMOD  .. " = 2147483647\n"

    -- bxor helper
    code = code .. "    local function " .. varBxor .. "(a, b)\n"
    code = code .. "        local r, m = 0, 1\n"
    code = code .. "        while a > 0 or b > 0 do\n"
    code = code .. "            local ra = a % 2\n"
    code = code .. "            local rb = b % 2\n"
    code = code .. "            if ra ~= rb then r = r + m end\n"
    code = code .. "            a = math.floor(a / 2)\n"
    code = code .. "            b = math.floor(b / 2)\n"
    code = code .. "            m = m * 2\n"
    code = code .. "        end\n"
    code = code .. "        return r\n"
    code = code .. "    end\n"

    -- hashMix helper
    code = code .. "    local function " .. varMix .. "(v, s)\n"
    code = code .. "        local h = (v * 2654435761 + s) % " .. varMOD .. "\n"
    code = code .. "        h = " .. varBxor .. "(h, math.floor(h / 65536))\n"
    code = code .. "        return h % " .. varMOD .. "\n"
    code = code .. "    end\n"

    -- trap constant check
    code = code .. "    local " .. varOk .. " = true\n"
    code = code .. "    local _trap_actual = " .. varMix .. "(" .. varTbl .. "[" .. tostring(trapIdx) .. "], " .. tostring(salt + trapIdx) .. ")\n"
    code = code .. "    if _trap_actual ~= " .. tostring(trapExpected) .. " then\n"
    code = code .. "        " .. varOk .. " = false\n"
    code = code .. "    end\n"

    -- rolling hash fold
    code = code .. "    local " .. varAcc .. " = " .. varTbl .. "[1]\n"
    code = code .. "    for " .. varI .. " = 2, " .. tostring(tableSize) .. " do\n"
    code = code .. "        " .. varAcc .. " = " .. varMix .. "(" .. varAcc .. ", " .. varTbl .. "[" .. varI .. "] + " .. varSalt .. ")\n"
    code = code .. "    end\n"
    code = code .. "    " .. varAcc .. " = " .. varAcc .. " % " .. varMOD .. "\n"

    -- final check + trap loop
    code = code .. "    if not " .. varOk .. " or " .. varAcc .. " ~= " .. tostring(expected) .. " then\n"
    code = code .. "        while true do\n"
    code = code .. "            " .. varOk .. " = not " .. varOk .. "\n"
    code = code .. "        end\n"
    code = code .. "    end\n"
    code = code .. "end\n"

    return code
end

-- ── apply ─────────────────────────────────────────────────────────────────────

function CffIntegrity:apply(ast, pipeline)
    local tableSize      = math.max(4, math.min(16, math.floor(self.TableSize or 9)))
    local trapIdxSetting = math.floor(self.TrapIndex or 0)

    local constants, trapIdx, expected, salt = buildTable(tableSize, trapIdxSetting)

    local code   = buildValidationCode(constants, trapIdx, expected, salt, tableSize)
    local parser = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 })
    local parsed = parser:parse(code)

    local doStat = parsed.body.statements[1]
    doStat.body.scope:setParent(ast.body.scope)

    table.insert(ast.body.statements, 1, doStat)

    return ast
end

return CffIntegrity
