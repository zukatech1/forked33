-- namegenerators/ghost.lua
-- Injects zero-width and invisible unicode characters into otherwise
-- normal-looking names. Visually identical to clean names but completely
-- different strings — ctrl+F, grep, and string matching all silently fail.

local util = require("ZukaTech.util")

-- Zero-width / invisible unicode characters valid in Lua identifiers
-- (Lua 5.1+ treats any byte >= 0x80 as a valid identifier character)
local ghosts = {
    "\xE2\x80\x8B",  -- Zero Width Space (U+200B)
    "\xE2\x80\x8C",  -- Zero Width Non-Joiner (U+200C)
    "\xE2\x80\x8D",  -- Zero Width Joiner (U+200D)
    "\xEF\xBB\xBF",  -- Zero Width No-Break Space / BOM (U+FEFF)
    "\xE2\x81\xA0",  -- Word Joiner (U+2060)
}

-- Normal-looking base names to poison with ghost chars
local bases = {
    "init", "load", "core", "main", "data", "meta",
    "node", "item", "list", "util", "base", "root",
    "loop", "tick", "step", "hook", "bind", "call",
    "send", "recv", "pack", "wrap", "pool", "slot",
    "flag", "mode", "type", "size", "count", "index",
    "value", "result", "target", "source", "handle",
    "state", "cache", "store", "queue", "stack",
}

-- How many ghost characters to inject per name
local MIN_GHOSTS = 1
local MAX_GHOSTS = 3

local ghostOrder = {}

local function injectGhosts(name, id)
    local count = MIN_GHOSTS + (id % (MAX_GHOSTS - MIN_GHOSTS + 1))
    local result = name
    for i = 1, count do
        local g = ghosts[((id + i) % #ghosts) + 1]
        -- Insert ghost at a position derived from id (not always end)
        local pos = (id * i) % (#result + 1)
        result = result:sub(1, pos) .. g .. result:sub(pos + 1)
    end
    return result
end

local function generateName(id, scope)
    local bi   = id % #bases
    local base = bases[ghostOrder[bi + 1]]
    -- Append a short numeric suffix so names stay unique across the id space
    local suffix = tostring(math.floor(id / #bases))
    local name   = suffix == "0" and base or (base .. suffix)
    return injectGhosts(name, id)
end

local function prepare(ast)
    util.shuffle(bases)
    util.shuffle(ghosts)
    ghostOrder = {}
    for i = 1, #bases do ghostOrder[i] = i end
    util.shuffle(ghostOrder)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
