-- ZukaTech Obfuscator — namegenerators/decesc.lua
-- Generates obfuscated identifier names and encoded string literals.
-- Fixed: generateName now returns valid identifiers; encoding is string-only.

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- State
-- ────────────────────────────────────────────────

local seed   = 0
local offset = 0

-- Charset split: identifiers must start with a letter or underscore (no digits).
-- We keep a separate "head" charset so the first character is always valid.
local charsetHead = util.chararray("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
local charsetTail = util.chararray("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789")

-- ────────────────────────────────────────────────
-- Hashing
-- ────────────────────────────────────────────────

--- Deterministic hash for a given numeric id + current seed.
---@param id number
---@return number
local function hashVal(id)
    -- Keep arithmetic inside 32-bit unsigned range.
    return (id * 2654435761 + seed * 0xBB38435) % 0xFFFFFFFF
end

-- ────────────────────────────────────────────────
-- Identifier Generation  (NO escape sequences here)
-- ────────────────────────────────────────────────

--- Builds a shuffled-charset identifier that is always a valid Lua name.
--- Length is pseudo-random but deterministic for a given id.
---@param id number
---@param len number?  Optional fixed length override.
---@return string  e.g. "xQbZmA", "T_wvKp"
local function baseEntropyName(id, len)
    local h = hashVal(id)
    len = len or (5 + (h % 7))  -- length in [5, 11]; avoids very short 4-char names

    -- First character: must be letter or underscore.
    local name = charsetHead[(h % #charsetHead) + 1]

    local v = h
    for _ = 1, len do
        -- LCG step (Knuth constants, truncated to 32-bit).
        v    = (v * 1664525 + 1013904223) % 0xFFFFFFFF
        name = name .. charsetTail[(v % #charsetTail) + 1]
    end

    return name
end

-- ────────────────────────────────────────────────
-- String Encoding  (escape sequences go HERE only)
-- ────────────────────────────────────────────────

--- Encodes every character of `str` as a decimal escape sequence.
--- Output is the raw sequence body, e.g.  \104\101\108\108\111
--- Suitable for embedding inside a string literal, NOT as an identifier.
---@param str string
---@return string
local function encodeString(str)
    local result = {}
    for i = 1, #str do
        result[i] = "\\" .. string.byte(str, i)
    end
    return table.concat(result)
end

--- Wraps an encoded string in double quotes, producing a valid Lua string literal.
--- e.g.  encodeStr("hi")  →  "\104\105"
---@param str string
---@return string
local function encodeStr(str)
    return '"' .. encodeString(str) .. '"'
end

--- Encodes a plain identifier name into an escape-sequence string literal.
--- Use this when you need the NAME itself to appear obfuscated inside a string
--- (e.g. for table key access via ["\104\101\108\108\111"]).
---@param id number
---@return string  e.g.  "\120\81\98\90"
local function encodeNameAsString(id)
    return encodeString(baseEntropyName(id + offset))
end

-- ────────────────────────────────────────────────
-- Public API
-- ────────────────────────────────────────────────

--- Returns a valid Lua identifier for use as a variable/function name in the AST.
--- This is what the AST node system calls when it needs a name token.
---@param id number
---@param scope any  Unused; reserved for future scope-aware generation.
---@return string  e.g. "xQbZmA_k"
local function generateName(id, scope)
    return baseEntropyName(id + offset)
end

--- Prepares the generator for a new obfuscation pass by re-shuffling
--- the charsets and re-seeding the hash state. Call once per pipeline run.
local function prepare(ast)
    util.shuffle(charsetHead)
    util.shuffle(charsetTail)
    seed   = math.random(0, 0xFFFF)
    offset = math.random(0, 9999)
end

return {
    generateName     = generateName,   -- valid identifier  → use for AST name nodes
    encodeStr        = encodeStr,       -- plain str → quoted escape-sequence literal
    encodeString     = encodeString,    -- plain str → raw escape-sequence body
    encodeNameAsString = encodeNameAsString, -- id → escape-seq body of the generated name
    prepare          = prepare,
}