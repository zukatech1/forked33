-- namegenerators/mirage.lua
-- Mirage — by Zuka
--
-- Generates names using only visually ambiguous characters:
-- I, O, l, 1, i, 0
--
-- In virtually every font these are near-identical:
--   I (capital i) vs l (lowercase L) vs 1 (one) vs i (lowercase i)
--   O (capital o) vs 0 (zero)
--
-- The result is completely unreadable at a glance — every name looks
-- like the same handful of characters rearranged. Even with syntax
-- highlighting it's brutal to follow.

local util = require("ZukaTech.util")

local MIN_CHARACTERS     = 6
local MAX_INITIAL_OFFSET = 12

-- The full ambiguous charset
local VarDigits      = { "I", "O", "l", "1", "i", "0" }

-- Start chars: no digits (1 and 0 can't start identifiers)
local VarStartDigits = { "I", "O", "l", "i" }

local offset = 0

local function generateName(id, scope)
    local name = ""
    local n    = id + offset

    -- First character from start-safe chars
    local d = n % #VarStartDigits
    n       = (n - d) / #VarStartDigits
    name    = name .. VarStartDigits[d + 1]

    -- Remaining characters from full charset
    -- Always generate at least MIN_CHARACTERS total length
    local count = 0
    repeat
        local dd = n % #VarDigits
        n        = (n - dd) / #VarDigits
        name     = name .. VarDigits[dd + 1]
        count    = count + 1
    until n == 0 and count >= MIN_CHARACTERS - 1

    return name
end

local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)
    offset = math.random(
        (#VarDigits) ^ MIN_CHARACTERS,
        (#VarDigits) ^ MAX_INITIAL_OFFSET
    )
end

return {
    generateName = generateName,
    prepare      = prepare,
}
