-- ZukaTech Obfuscator — namegenerators/il.lua
-- Fixed: scope passed as table from pipeline, not a number. Added pure Lua 5.1 bxor.

local util      = require("ZukaTech.util")
local chararray = util.chararray

-- ────────────────────────────────────────────────
-- Config
-- ────────────────────────────────────────────────

local MIN_LENGTH     = 8
local MAX_OFFSET_EXP = 12
local MIN_OFFSET_EXP = 8

-- ────────────────────────────────────────────────
-- Charset Tiers
-- ────────────────────────────────────────────────

local VarStartDigits = chararray("Il")
local VarDigits      = chararray("Il1")

-- ────────────────────────────────────────────────
-- Per-run State
-- ────────────────────────────────────────────────

local offset   = 0
local salt     = 0
local checkKey = 0

-- ────────────────────────────────────────────────
-- Pure Lua 5.1 Bitwise XOR (no bit library)
-- ────────────────────────────────────────────────

local function bxor(a, b)
    local result = 0
    local bit    = 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then result = result + bit end
        a   = math.floor(a / 2)
        b   = math.floor(b / 2)
        bit = bit * 2
    end
    return result
end

-- ────────────────────────────────────────────────
-- Internal: Base-N Encoder
-- ────────────────────────────────────────────────

local function encodeId(id)
    local name = ""

    local d = id % #VarStartDigits
    id      = math.floor((id - d) / #VarStartDigits)
    name    = VarStartDigits[d + 1]

    while id > 0 do
        d    = id % #VarDigits
        id   = math.floor((id - d) / #VarDigits)
        name = name .. VarDigits[d + 1]
    end

    return name
end

-- ────────────────────────────────────────────────
-- Internal: Padding
-- ────────────────────────────────────────────────

local function pad(name, id)
    local v = id
    while #name < MIN_LENGTH do
        v    = (v * 1664525 + 1013904223) % 0xFFFFFFFF
        name = name .. VarDigits[(v % #VarDigits) + 1]
    end
    return name
end

-- ────────────────────────────────────────────────
-- Internal: Checksum Interlacing
-- ────────────────────────────────────────────────

local function interlace(name, id)
    local pos      = ((id * 31 + checkKey) % #name) + 1
    local charIdx  = ((id * 17 + checkKey * 7) % #VarDigits) + 1
    local injected = VarDigits[charIdx]
    return name:sub(1, pos) .. injected .. name:sub(pos + 1)
end

-- ────────────────────────────────────────────────
-- Internal: Scope Salt
-- ────────────────────────────────────────────────

--- Safely extracts a numeric depth from whatever the pipeline passes as scope.
--- The pipeline passes a scope TABLE, not a number — we pull .depth if it exists.
---@param scope any   Could be nil, number, or a scope table.
---@return number     A safe numeric depth value, defaulting to 0.
local function scopeDepth(scope)
    if type(scope) == "number" then
        return scope
    elseif type(scope) == "table" then
        -- Common field names used by scope objects in ZukaTech pipeline.
        return tonumber(scope.depth or scope.level or scope.id or 0) or 0
    end
    return 0
end

local function applyScope(id, scope)
    local depth = scopeDepth(scope)   -- always a safe number now
    if depth > 0 then
        return (id * 2654435761 + depth * 2246822519) % 0xFFFFFFFF
    end
    return id % 0xFFFFFFFF
end

-- ────────────────────────────────────────────────
-- Public: generateName
-- ────────────────────────────────────────────────

local function generateName(id, scope)
    id = applyScope(id, scope)
    id = bxor((id + offset) % 0xFFFFFFFF, salt) % 0xFFFFFFFF

    local name = encodeId(id)
    name = pad(name, id)
    name = interlace(name, id)

    return name
end

-- ────────────────────────────────────────────────
-- Public: prepare
-- ────────────────────────────────────────────────

local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)

    offset   = math.random(3 ^ MIN_OFFSET_EXP, 3 ^ MAX_OFFSET_EXP)
    salt     = math.random(0, 0xFFFFFF)
    checkKey = math.random(0, 0xFFFF)
end

-- ────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}