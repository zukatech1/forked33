-- namegenerators/phantom.lua
-- Phantom — by Zuka
--
-- The most analytically deceptive generator.
-- Names LOOK like normal ASCII identifiers — real words, readable —
-- but every single character is a unicode lookalike or has invisible
-- zero-width characters injected between letters.
--
-- Visually: "result" "table" "index" "value"
-- Actually:  ｒｅｓｕｌｔ  ｔａｂｌｅ  ｉｎｄｅｘ  ｖａｌｕｅ
--             (fullwidth latin, not ASCII)
--
-- Why it's the nastiest:
--   - Names look 100% like real variables — the reverser thinks they understand the code
--   - Ctrl+F for "result" finds nothing — it's not ASCII
--   - Decompilers may normalize them OR may not — inconsistent behavior
--   - Mixing ghost chars INSIDE fullwidth names breaks string length assumptions
--   - Pattern matching on "looks like a real variable" fails completely

local util = require("ZukaTech.util")

-- Fullwidth latin (U+FF01–U+FF5E) — visually identical to ASCII at most sizes
-- Each fullwidth char is 3 bytes: \xEF\xBC\x81 to \xEF\xBD\x9E
-- a=\xEF\xBD\x81, b=\xEF\xBD\x82 ... z=\xEF\xBD\x9A
-- A=\xEF\xBC\xA1 ... Z=\xEF\xBC\xBA
local FW = {
    a="\xEF\xBD\x81", b="\xEF\xBD\x82", c="\xEF\xBD\x83", d="\xEF\xBD\x84",
    e="\xEF\xBD\x85", f="\xEF\xBD\x86", g="\xEF\xBD\x87", h="\xEF\xBD\x88",
    i="\xEF\xBD\x89", j="\xEF\xBD\x8A", k="\xEF\xBD\x8B", l="\xEF\xBD\x8C",
    m="\xEF\xBD\x8D", n="\xEF\xBD\x8E", o="\xEF\xBD\x8F", p="\xEF\xBD\x90",
    q="\xEF\xBD\x91", r="\xEF\xBD\x92", s="\xEF\xBD\x93", t="\xEF\xBD\x94",
    u="\xEF\xBD\x95", v="\xEF\xBD\x96", w="\xEF\xBD\x97", x="\xEF\xBD\x98",
    y="\xEF\xBD\x99", z="\xEF\xBD\x9A",
}

-- Invisible zero-width chars to inject as separators
local ZWSP = {
    "\xE2\x80\x8B",  -- U+200B Zero Width Space
    "\xE2\x80\x8C",  -- U+200C Zero Width Non-Joiner
    "\xE2\x80\x8D",  -- U+200D Zero Width Joiner
    "\xEF\xBB\xBF",  -- U+FEFF BOM / Zero Width No-Break Space
}

-- Plausible-looking base words — the deceptive core
local WORDS = {
    "result",  "index",  "value",  "table",  "data",
    "state",   "count",  "total",  "local",  "node",
    "cache",   "store",  "list",   "queue",  "stack",
    "scope",   "target", "source", "handle", "entry",
    "buffer",  "cursor", "record", "object", "module",
    "config",  "filter", "parser", "loader", "runner",
    "event",   "signal", "update", "render", "output",
    "input",   "params", "args",   "flags",  "option",
    "context", "frame",  "layer",  "vertex", "shader",
    "matrix",  "vector", "normal", "weight", "offset",
}

-- Numeric suffixes to extend the id space
local SUFFIXES = { "", "0", "1", "2", "_v", "_t", "_n", "_x" }

local wordOrder   = {}
local suffixOrder = {}
local seed        = 0

local function prng(n)
    n = (n * 2654435761 + seed) % 0x100000000
    local result, bit, x, y = 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x = math.floor(x / 2); y = math.floor(y / 2); bit = bit * 2
    end
    return result
end

-- Convert a plain ASCII word to fullwidth
local function toFullwidth(word)
    local result = ""
    for i = 1, #word do
        local c = word:sub(i, i)
        result = result .. (FW[c] or c)
    end
    return result
end

-- Inject 1-2 zero-width chars at random interior positions
local function injectPhantoms(name, id)
    local zwCount = 1 + (prng(id * 5) % 2)
    for i = 1, zwCount do
        local zw  = ZWSP[(prng(id * 11 + i) % #ZWSP) + 1]
        -- inject somewhere in the middle, not at start
        local pos = 3 + (prng(id * 7 + i * 3) % math.max(1, #name - 3))
        name = name:sub(1, pos) .. zw .. name:sub(pos + 1)
    end
    return name
end

local function generateName(id, scope)
    local wi   = id % #WORDS
    local si   = (math.floor(id / #WORDS)) % #SUFFIXES
    local word = WORDS[wordOrder[wi + 1]]
    local suf  = SUFFIXES[suffixOrder[si + 1]]

    -- Convert to fullwidth
    local fw   = toFullwidth(word .. suf)

    -- Inject invisible chars
    return "_" .. injectPhantoms(fw, id)
end

local function prepare(ast)
    seed        = math.random(0, 0xFFFFFF)
    wordOrder   = {}
    suffixOrder = {}
    for i = 1, #WORDS   do wordOrder[i]   = i end
    for i = 1, #SUFFIXES do suffixOrder[i] = i end
    util.shuffle(wordOrder)
    util.shuffle(suffixOrder)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
