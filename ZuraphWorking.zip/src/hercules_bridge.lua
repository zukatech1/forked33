-- ZukaTechV2: hercules_bridge.lua
-- Bridges Hercules obfuscator modules into the ZukaTechV2 pipeline.
-- Hercules works at the string/token level (no AST), so it runs
-- AFTER ZukaTech's AST passes and receives their unparsed output.

local function script_path()
	local str = debug.getinfo(2, "S").source:sub(2)
	return str:match("(.*[/\\])") or ""
end

local base = script_path()

-- Temporarily redirect requires so Hercules modules resolve correctly
local function herculesRequire(modname)
	local modpath = base .. "hercules/modules/" .. modname:gsub("%.", "/") .. ".lua"
	local chunk, err = loadfile(modpath)
	if not chunk then
		-- try nested Compiler path
		modpath = base .. "hercules/modules/Compiler/" .. modname .. ".lua"
		chunk, err = loadfile(modpath)
	end
	if not chunk then
		error("hercules_bridge: cannot load module '" .. modname .. "': " .. tostring(err))
	end
	return chunk()
end

-- Load Hercules config independently (isolated table, not global)
local HerculesConfig = (function()
	local cfg = {}
	cfg.settings = {
		watermark_enabled     = false, -- ZukaTech handles watermarks
		VirtualMachine        = { enabled = true }, -- ZukaTech Vmify handles this
		antitamper            = { enabled = false }, -- disabled globally
		control_flow          = { enabled = true,  max_fake_blocks = 6 },
		StringToExpressions   = { enabled = false, min_number_length = 100, max_number_length = 999 },
		string_encoding       = { enabled = false },
		WrapInFunction        = { enabled = false }, -- ZukaTech WrapInFunction handles this
		variable_renaming     = { enabled = false,  min_name_length = 8, max_name_length = 12 },
		garbage_code          = { enabled = false,  garbage_blocks = 15 },
		opaque_predicates     = { enabled = false },
		function_inlining     = { enabled = false },
		dynamic_code          = { enabled = false },
		bytecode_encoding     = { enabled = true },
		compressor            = { enabled = false }, -- ZukaTech Compressor handles this
	}

	function cfg.get(key)
		local keys = {}
		for k in key:gmatch("[^.]+") do table.insert(keys, k) end
		local value = cfg
		for _, k in ipairs(keys) do
			value = value[k]
			if value == nil then return nil end
		end
		return value
	end

	function cfg.set(key, new_value)
		local keys = {}
		for k in key:gmatch("[^.]+") do table.insert(keys, k) end
		local value = cfg
		for i = 1, #keys - 1 do
			value = value[keys[i]]
			if value == nil then return false end
		end
		local last_key = keys[#keys]
		if value[last_key] ~= nil then
			value[last_key] = new_value
			return true
		end
		return false
	end

	return cfg
end)()

-- Lazily load each Hercules module, passing them a shimmed require
local function loadHerculesModule(name)
	local modpath = base .. "hercules/modules/" .. name .. ".lua"
	local chunk, err = loadfile(modpath)
	if not chunk then
		error("hercules_bridge: cannot load '" .. name .. "': " .. tostring(err))
	end

	-- Build a sandboxed env where require() resolves relative to hercules/modules
	local env = setmetatable({}, { __index = _G })
	env.require = function(req)
		-- Strip leading path noise
		local plain = req:match("([^/\\]+)$") or req
		-- Try known locations
		local paths = {
			base .. "hercules/modules/" .. plain .. ".lua",
			base .. "hercules/modules/Compiler/" .. plain .. ".lua",
		}
		for _, p in ipairs(paths) do
			local c, e = loadfile(p)
			if c then
				setfenv(c, env)
				return c()
			end
		end
		-- Fall back to the host require
		return require(req)
	end

	setfenv(chunk, env)
	return chunk()
end

-- Module cache
local moduleCache = {}
local function getModule(name)
	if not moduleCache[name] then
		moduleCache[name] = loadHerculesModule(name)
	end
	return moduleCache[name]
end

-- ----------------------------------------------------------------
-- Public API
-- ----------------------------------------------------------------

local HerculesBridge = {}

-- Apply Hercules passes to a code string.
-- `options` is a table of bool flags:
--   control_flow, variable_renaming, garbage_code,
--   opaque_predicates, string_encoding, StringToExpressions,
--   dynamic_code, function_inlining, bytecode_encoding
function HerculesBridge.process(code, options)
	options = options or {}

	-- Override config with caller's choices
	-- NOTE: antitamper is permanently disabled — it conflicts with ZukaTech output
	local boolFlags = {
		"control_flow", "variable_renaming", "garbage_code",
		"opaque_predicates", "string_encoding", "StringToExpressions",
		"dynamic_code", "function_inlining", "bytecode_encoding",
		-- "antitamper" intentionally excluded
	}
	for _, flag in ipairs(boolFlags) do
		if options[flag] ~= nil then
			HerculesConfig.settings[flag] = HerculesConfig.settings[flag] or {}
			HerculesConfig.settings[flag].enabled = options[flag]
		end
	end

	-- Preset-level intensity knobs
	if options.intensity == "max" then
		HerculesConfig.settings.variable_renaming.min_name_length = 60
		HerculesConfig.settings.variable_renaming.max_name_length = 90
		HerculesConfig.settings.garbage_code.garbage_blocks       = 40
		HerculesConfig.settings.control_flow.max_fake_blocks      = 12
	elseif options.intensity == "mid" then
		HerculesConfig.settings.variable_renaming.min_name_length = 30
		HerculesConfig.settings.variable_renaming.max_name_length = 50
		HerculesConfig.settings.garbage_code.garbage_blocks       = 20
		HerculesConfig.settings.control_flow.max_fake_blocks      = 8
	end

	-- Run passes in the same order as Hercules pipeline.lua
	if HerculesConfig.get("settings.string_encoding.enabled") then
		local ok, result = pcall(function()
			return getModule("string_encoder").process(code)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.garbage_code.enabled") then
		local blocks = HerculesConfig.get("settings.garbage_code.garbage_blocks")
		local ok, result = pcall(function()
			return getModule("garbage_code_inserter").process(code, blocks)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.dynamic_code.enabled") then
		local ok, result = pcall(function()
			return getModule("dynamic_code_generator").process(code)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.opaque_predicates.enabled") then
		local ok, result = pcall(function()
			return getModule("opaque_predicate_injector").process(code)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.function_inlining.enabled") then
		local ok, result = pcall(function()
			return getModule("function_inliner").process(code)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.StringToExpressions.enabled") then
		local minL = HerculesConfig.get("settings.StringToExpressions.min_number_length")
		local maxL = HerculesConfig.get("settings.StringToExpressions.max_number_length")
		local ok, result = pcall(function()
			return getModule("StringToExpressions").process(code, minL, maxL)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.control_flow.enabled") then
		local maxFake = HerculesConfig.get("settings.control_flow.max_fake_blocks")
		local ok, result = pcall(function()
			return getModule("control_flow_obfuscator").process(code, maxFake)
		end)
		if ok then code = result end
	end

	-- Second garbage pass (mirrors Hercules pipeline.lua)
	if HerculesConfig.get("settings.garbage_code.enabled") then
		local blocks = HerculesConfig.get("settings.garbage_code.garbage_blocks")
		local ok, result = pcall(function()
			return getModule("garbage_code_inserter").process(code, blocks)
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.variable_renaming.enabled") then
		local minL = HerculesConfig.get("settings.variable_renaming.min_name_length")
		local maxL = HerculesConfig.get("settings.variable_renaming.max_name_length")
		local ok, result = pcall(function()
			return getModule("variable_renamer").process(code, { min_length = minL, max_length = maxL })
		end)
		if ok then code = result end
	end

	if HerculesConfig.get("settings.bytecode_encoding.enabled") then
		local ok, result = pcall(function()
			return getModule("bytecode_encoder").process(code)
		end)
		if ok then code = result end
	end

	return code
end

-- Expose config for external tweaking
HerculesBridge.Config = HerculesConfig

return HerculesBridge
