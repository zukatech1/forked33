return {
	["Mini"] = {
		LuaVersion = "Lua51"; VarNamePrefix = "_z"; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "Vmify";          Settings = {} };
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
	["Weak"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Unicode";
		PrettyPrint = true; Seed = 0;
		Steps = {
			{ Name = "VariableRenamer"; Settings = {} };
			{ Name = "BytecodeEncoder"; Settings = {} };
			


		};
		Hercules = nil;
	};
	["Default"] = {
		LuaVersion = "Lua51"; VarNamePrefix = "_z"; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "Vmify";          Settings = {} };
			{ Name = "EncryptStrings"; Settings = {} };
			{ Name = "DynamicXOR";     Settings = { Treshold = 0.2 } };
			{ Name = "ConstantArray";  Settings = {
				Treshold = 0.75; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 5;
			}};
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
	["Medium"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "ZukaZalgo";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = {} };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = nil;
	};
	["Strong"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "Vmify";                Settings = {} };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = {} };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = nil;
	};
	["Executor"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "ZukaZalgo";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
			{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.6; InjectionsPerBlock = 1 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "Compressor";           Settings = { MinLength = 10 } };
		};
		Hercules = nil;
	};
	["VmifyBC"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {

			{ Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = true } };
			--{ Name = "BlobCompress";         Settings = {} };



		};
		Hercules = nil;
	};
	["Main"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "ShadowRegisters";      Settings = { Density = 0.3; ShadowSize = 20 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 2; Treshold = 0.9; TableWriteRatio = 0.5;
				ChainLength = 4; TableWriteCount = 3;
			}};
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "Compressor";           Settings = { MinLength = 10 } };
		};
		Hercules = nil;
	};
	["Tier1_BC"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "lI";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "CffIntegrity";         Settings = { TableSize = 7; TrapIndex = 0 } };
			{ Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.25 } };
			{ Name = "ShadowRegisters";      Settings = { Density = 0.3; ShadowSize = 20 } };
			{ Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 2; Treshold = 0.9; TableWriteRatio = 0.5;
				ChainLength = 4; TableWriteCount = 3;
			}};
			{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "BlobCompress";         Settings = {} };
		};
		Hercules = nil;
	};
	["NoVmMax"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "MangledShuffled";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
			{ Name = "ConstantsObfuscator";  Settings = {
				ObfuscateNumbers = true; ObfuscateStrings = true;
				MockStringChance = 6; MinAbsValue = 3;
			}};
			{ Name = "ShadowRegisters";      Settings = { Density = 0.35; ShadowSize = 24 } };
			{ Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.75 } };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 5; Treshold = 0.8; TableWriteRatio = 0.5;
				ChainLength = 3; TableWriteCount = 3;
			}};
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.25 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = { control_flow = true; garbage_code = true; opaque_predicates = true; variable_renaming = true; string_encoding = true; intensity = "max" };
	};
	["ZuraphMax"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "AntiDump";             Settings = { GCInterval = 60 } };
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "SplitStrings";       Settings = {} };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "ConstantsObfuscator";  Settings = {
				ObfuscateNumbers = true; ObfuscateStrings = true;
				MockStringChance = 8; MinAbsValue = 5;
			}};
			{ Name = "ShadowRegisters";      Settings = { Density = 0.4; ShadowSize = 32 } };
			{ Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.85 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.8 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			{ Name = "AntiDump";             Settings = { GCInterval = 60 } };
			{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.4 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "Compressor";           Settings = { MinLength = 10 } };
		};
		Hercules = nil;
	};
	["ZuraphMax_BC"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
			{ Name = "AntiDump";       Settings = {} };
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			--{ Name = "CffIntegrity";         Settings = { TableSize = 9; TrapIndex = 0 } };
			--{ Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
			--{ Name = "ConstantsObfuscator";  Settings = {
			--	ObfuscateNumbers = true; ObfuscateStrings = false;
			--	MockStringChance = 8; MinAbsValue = 5;
			--}};
			{ Name = "ShadowRegisters";      Settings = { Density = 0.4; ShadowSize = 32 } };
			{ Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.85 } };
			--{ Name = "ConstantArray";        Settings = {
				--Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				--LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			--}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			--{ Name = "JunkStatements";       Settings = {
				--InjectionCount = 4; Treshold = 0.9; TableWriteRatio = 0.5;
				--ChainLength = 4; TableWriteCount = 4;
			--}};
			{ Name = "AntiDump";             Settings = { GCInterval = 60 } };
			--{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			--{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.4 } };
			--{ Name = "WrapInFunction";       Settings = {} };
			--{ Name = "BlobCompress";         Settings = {} };
			--{ Name = "Compressor";           Settings = { MinLength = 10 } };

		};
		Hercules = nil;
	};
	["HttpGet"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Unicode";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "EncryptStrings"; Settings = {} };
			{ Name = "DynamicXOR";     Settings = { Treshold = 1 } };
			{ Name = "Vmify";          Settings = {} };
			{ Name = "ConstantArray";  Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 8;
			}};
			{ Name = "JunkStatements"; Settings = {
				InjectionCount = 2; Treshold = 0.7; TableWriteRatio = 0.4;
				ChainLength = 2; TableWriteCount = 2;
			}};
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = { control_flow = true; garbage_code = true; opaque_predicates = false; variable_renaming = false; intensity = "mid" };
	};
	["Debug"] = {
		LuaVersion = "Lua51"; VarNamePrefix = "_z"; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = false } };
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
}